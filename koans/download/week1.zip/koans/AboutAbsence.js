describe('about absence', function() {

  it('should have a type', function() {
    expect(null).toHaveType(FILL_ME_IN);
    expect(undefined).toHaveType(FILL_ME_IN);
    expect(aVariableCalledFromOutOfTheAbyss).toHaveType(FILL_ME_IN);
  });

});